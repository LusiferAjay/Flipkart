# Flipkart
Model Training on the Flipkart Dataset.

DenseNet and ResNeXt.
